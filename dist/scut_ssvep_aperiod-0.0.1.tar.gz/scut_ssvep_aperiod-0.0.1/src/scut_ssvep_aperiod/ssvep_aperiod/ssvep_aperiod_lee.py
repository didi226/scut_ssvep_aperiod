from scut_ssvep_aperiod.load_dataset.dataset_kalunga import LoadDataKalungaOne
from scut_ssvep_aperiod.load_dataset.dataset_lee import LoadDataLeeOne
from scut_ssvep_aperiod.ssvep_method import CCACommon,TRCA,FBCCA,TDCA,PSDA
from scut_ssvep_aperiod.utils.common_function import cal_acc
import pandas as pd
import numpy as np
import os
def ssvep_classify(form_path, info_path, pro_ica = True, filter_para = None, reconstruct_ = False,reconstruct_type=2):
	info_form = pd.read_excel(form_path)
	unique_subject_ids = info_form['subject_id'].unique()
	acc_all = np.zeros(len(unique_subject_ids))
	for subject_id in unique_subject_ids:
		subject_rows = info_form.loc[info_form['subject_id'] == subject_id]
		root_directory = subject_rows['root_directory'].tolist()
		file_name = subject_rows['file_name'].tolist()
		data_path = os.path.join(root_directory[0], file_name[0])
		datasetone = LoadDataLeeOne(data_path,info_path = info_path)
		test_data, test_label, train_data, train_label = datasetone.get_data(pro_ica = pro_ica, filter_para = filter_para,
                                                            resample = 4, reconstruct_ = reconstruct_, reconstruct_type = reconstruct_type)
		#psda
		# ssvep_method = PSDA(datasetone.sample_rate_test, datasetone.window_time, datasetone.freqs, 3,psd_type = "Ordinary",
		#                     psd_channel = "ave", psda_type = "snr_hqy")
		# predict_label = ssvep_method.classify(test_data)
		# #cca
		ccaoriginal_classify = CCACommon(Fs = datasetone.sample_rate_test, ws = datasetone.window_time,
		                                 fres_list = datasetone.freqs, n_harmonics = 3)
		predict_label = ccaoriginal_classify.classify(test_data, ica_ = False)
		# fbcca
		# ssvep_method = FBCCA(datasetone.sample_rate_test, datasetone.window_time, datasetone.freqs, 3)
		# predict_label = ssvep_method.classify(test_data)
		#trca
		# ssvep_method = TRCA(datasetone.sample_rate_test, datasetone.window_time, datasetone.freqs,3)
		# ssvep_method.train(train_data, train_label)
		# predict_label = ssvep_method.classifier(test_data)
		#tdca
		# ssvep_method = TDCA(datasetone.sample_rate_test, datasetone.window_time, datasetone.freqs,3)
		# ssvep_method.train(train_data, train_label)
		# predict_label = ssvep_method.classifier(test_data)
		acc = cal_acc(Y_true = test_label, Y_pred = predict_label)
		print(test_label, predict_label)
		print(acc)
		print(subject_id)
		acc_all[subject_id-1] = acc
	print(acc_all.mean())
if __name__ == "__main__":
	form_path_lee = "D:\data\ssvep_dataset\MNE-lee2019-ssvep-data\session1\ssvep_lee_sub_info_session1.xlsx"
	info_path = r"D:\data\ssvep_dataset\MNE-lee2019-ssvep-data\info_ssvep_lee_dataset.mat"
	ssvep_classify(form_path_lee, info_path, pro_ica = True, filter_para=None, reconstruct_=False, reconstruct_type=None)
	ssvep_classify(form_path_lee, info_path, pro_ica = True, filter_para = [1,40], reconstruct_ = False, reconstruct_type = None)
	ssvep_classify(form_path_lee, info_path, pro_ica = True, filter_para = [1,40], reconstruct_ = "remove_aperiodic", reconstruct_type = 0)
	ssvep_classify(form_path_lee, info_path, pro_ica = True, filter_para =[1, 40], reconstruct_ = "get_periodic", reconstruct_type = 0)
	ssvep_classify(form_path_lee, info_path, pro_ica = True, filter_para = [1, 40], reconstruct_ = "get_aperiodic", reconstruct_type = 0)
	ssvep_classify(form_path_lee, info_path, pro_ica = True, filter_para = [1, 40], reconstruct_ = "remove_aperiodic", reconstruct_type = 2)
	ssvep_classify(form_path_lee, info_path, pro_ica = True, filter_para = [1,40], reconstruct_ = "get_periodic", reconstruct_type = 2)
	ssvep_classify(form_path_lee, info_path, pro_ica = True, filter_para = [1,40], reconstruct_ = "get_aperiodic", reconstruct_type = 2)
