import numpy as np
import scipy.io as sio
from mne.io import RawArray
from mne import create_info
from scut_ssvep_aperiod.utils.common_function import ica_iclabel
from scipy import signal
class LoadDataBase:
	def __init__(self, data_path):
		self.data_path = data_path
		self.window_time = 4-0.14
		# self.sample_rate = None
		# self.split_data = []
		# self.label = []
		# self.n_epoch = None
		# self.n_channel = None


	@staticmethod
	def preprocess(raw, ica_ = True,filter_para = None):
		if filter_para is not None:
			raw = raw.copy().filter(filter_para[0], filter_para[1])
		if ica_:
			raw = ica_iclabel(raw, n_components = None, remove_label
			                   ={'muscle artifact': 0.9, 'eye blink': 0.9, 'heart beat': 0.9})
		return raw

	def get_data(self, ica_= True,filter_para = None):
		pass



if __name__ == "__main__":
	cc=1
